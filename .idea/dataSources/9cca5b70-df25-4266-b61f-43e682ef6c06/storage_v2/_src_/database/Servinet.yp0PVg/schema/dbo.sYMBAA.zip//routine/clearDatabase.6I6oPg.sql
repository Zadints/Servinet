CREATE PROCEDURE clearDatabase
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM users_session;
    DELETE FROM users;
    DELETE FROM role_permissions;
    DELETE FROM antennas;
    DELETE FROM roles;
    DELETE FROM appGeneral;
END;
go

